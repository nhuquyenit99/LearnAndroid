package com.example.reconizetext;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.googlecode.tesseract.android.TessBaseAPI;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    ImageView imgInput;
    TessBaseAPI mTess;
    Button btnReconize;
    Button btnCalculate;
    TextView tvResult;
    TextView tvCalculate;
    String result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
            prepareData("eng");
        } catch (IOException e) {
            e.printStackTrace();
        }
        mTess = new TessBaseAPI();
        mTess.init(getFilesDir()+"","eng");
        imgInput = findViewById(R.id.img_input);
        Bitmap input = BitmapFactory.decodeResource(getResources(),R.drawable.equ_image_test);
        imgInput.setImageBitmap(input);

        btnReconize = findViewById(R.id.btn_reconize);
        btnCalculate = findViewById(R.id.btn_calculate);
        tvResult = findViewById(R.id.tv_result);
        tvCalculate = findViewById(R.id.tv_calculate);

        btnReconize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mTess.setImage(BitmapFactory.decodeResource(getResources(),R.drawable.equ_image_test));
                result = mTess.getUTF8Text();
                tvResult.setText(result);
            }
        });

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(result!=""){
                    tvCalculate.setText(Double.toString(calculate(result)));
                }
            }
        });

    }

    public void prepareData(String mode) throws IOException {
        String fileTrainedData = "";
        switch (mode) {
            case "vie":
            {
                fileTrainedData = "vie.traineddata";
                break;
            }
            case "eng":
            {
                fileTrainedData = "eng.traineddata";
                break;
            }
            case "equ":
            {
                fileTrainedData = "equ.traineddata";
                break;
            }
            default: fileTrainedData = "eng.traineddata";
        }
        //Copy file from asset to public folder
        File dir = new File(getFilesDir()+"/tessdata");
        if(!dir.exists()) {
            dir.mkdir();
        }
        File trainedData = new File(getFilesDir()+"/tessdata/"+fileTrainedData);
        if(!trainedData.exists()){
            AssetManager asset = getAssets();
            InputStream is = asset.open("tessdata/"+fileTrainedData);
            OutputStream os = new FileOutputStream(getFilesDir()+"/tessdata/"+fileTrainedData);
            byte[] buffer = new byte[1024];
            int read;
            while ((read=is.read(buffer))!=-1) {
                os.write(buffer,0,read);
            }
            is.close();os.flush();os.close();
        }//close

    }

    public double calculate(String input) {
        //Mảng chứa các phép tính +, - , x, /
        ArrayList<String> arrOperation;
        //Mảng chứa các số
        ArrayList<Double> arrNumber;

        //Lấy tất cả các phép tính lưu vào mảng arrOperation

        arrOperation = new ArrayList<>();
            char[] cArray = input.toCharArray();
            for (int i = 0; i < cArray.length; i++) {
                switch (cArray[i]) {
                    case '+':
                        arrOperation.add(cArray[i] + "");
                        break;
                    case '-':
                        arrOperation.add(cArray[i] + "");
                        break;
                    case '*':
                        arrOperation.add(cArray[i] + "");
                        break;
                    case '/':
                        arrOperation.add(cArray[i] + "");
                        break;
                    default:
                        break;
                }
            }

        //Lấy tất cả các số lưu vào mảng arrNumber
            arrNumber = new ArrayList<>();
            Pattern regex = Pattern.compile("(\\d+(?:\\.\\d+)?)");
            Matcher matcher = regex.matcher(input);
            while (matcher.find()) {
                arrNumber.add(Double.valueOf(matcher.group(1)));
            }

            double result=0;
        if (arrOperation.size() >= arrNumber.size() || arrOperation.size() < 1) {
            tvResult.setText("Lỗi định dạng");
        } else {
            for (int i = 0; i < (arrNumber.size() - 1); i++) {
                switch (arrOperation.get(i)) {
                    case "+":
                        if (i == 0) {
                            result = arrNumber.get(i) + arrNumber.get(i + 1);
                        } else {
                            result = result + arrNumber.get(i + 1);
                        }
                        break;
                    case "-":
                        if (i == 0) {
                            result = arrNumber.get(i) - arrNumber.get(i + 1);
                        } else {
                            result = result - arrNumber.get(i + 1);
                        }
                        break;
                    case "*":
                        if (i == 0) {
                            result = arrNumber.get(i) * arrNumber.get(i + 1);
                        } else {
                            result = result * arrNumber.get(i + 1);
                        }
                        break;
                    case "/":
                        if (i == 0) {
                            result = arrNumber.get(i) / arrNumber.get(i + 1);
                        } else {
                            result = result / arrNumber.get(i + 1);
                        }
                        break;
                    default:
                        break;
                }
            }
        }

            return result;
    }
}
